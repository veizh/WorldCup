import React,{ useState }  from'react'
import "./select.css" 


const Selectbox = (props) =>{

        const [activeselection,setActiveSelection] = useState(props.placeholder)
        const [active,setActive] = useState(false)
    
    
        const toggleActive = ()=>{
            if(active){
                setActive(false)
            }
            else setActive(true)
        }

        const labelSelected = (e) =>{
            setActive(false)
             setActiveSelection(e);
        }

         /* Recuperer les equipes probable de selectionner a l'endroit x et l'instant t */ 
    return (
            <div className="containerSelect">
                <div className={ active?'selected active':'selected'} onClick={toggleActive} >{activeselection}</div>   

                <div className="select-box">
                    <div className={ active?'options-container active':'options-container'}>
                        <div onClick={()=>{labelSelected('FRANCE')}} className="option" id='FRANCE'>
                            <input type="radio" className='radio' name='equipe' id='FRANCE'/>
                            <label htmlFor="FRANCE">FRANCE</label>
                        </div>
                        <div onClick={()=>{labelSelected('SENEGAL')}}className="option" id='SENEGAL'>
                            <input type="radio" className='radio' name='equipe' id='SENEGAL'/>
                            <label htmlFor="SENEGAL">SENEGAL</label>
                        </div>
                        <div onClick={()=>{labelSelected('ANGLETERRE')}} className="option" id='ANGLETERRE'>
                            <input type="radio" className='radio' name='equipe' id='ANGLETERRE'/>
                            <label htmlFor="ANGLETERRE">ANGLETERRE</label>
                        </div>
                        <div onClick={()=>{labelSelected('SUEDE')}} className="option" id='SUEDE'>
                            <input type="radio" className='radio' name='equipe' id='SUEDE'/>
                            <label htmlFor="SUEDE">SUEDE</label>
                        </div>  
                    </div>
                </div> 
                   
            </div>
            )
}

export default Selectbox