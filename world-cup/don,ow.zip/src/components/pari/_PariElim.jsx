import React, { useState } from "react"
import Selectbox from "../select/_Select"
import './pariElim.css'

const WindowPari = () =>{
    const [Active,setActive] = useState(false)
    const toggleActive =()=>{
        if(Active){
            setActive(false)}
        else setActive(true)
    }

    const [valider,setValider]=useState(false)
    const togglevalider =()=>{
        if(!valider){
            setValider(true)}
    }
    const getInfo=()=>{
        const array = document.querySelectorAll('.selected')
        array.forEach((e)=>{
            console.log(e.innerHTML);
        })
    }
    return( 
            <>
                <div className="match" onClick={toggleActive}><span>Match X</span>{valider?<i className="fa-solid fa-circle-check"></i>:<i className="fa-solid fa-chevron-right"></i>}</div>

                <div className={Active?"containerPairing active":"containerPairing"}>
                    <div className="filtre" >
                        <div className="boxMatch">
                        <Selectbox name="8.1" placeholder="1er de la poule A"/>
                        <Selectbox name="8.2" placeholder="2eme de la poule B"/>
                        <button onClick={()=>{
                        toggleActive()
                        togglevalider()
                        getInfo()
                        }}>Valider</button>
                        </div>

                    </div>
                    
                </div>
             </>
    )
}

const Huitieme = () => {
    return(
        <div className="containerElim huitieme">
        <div className="title">Huitième de Finale</div>
            <WindowPari />
            <WindowPari />
            <WindowPari />
            <WindowPari />
            <WindowPari />
            <WindowPari />
            <WindowPari />
            <WindowPari />

    </div>
    )
}
const Quart = () => {
    return(
        <div className="containerElim quart">
        <div className="title">Quart de Finale</div>
            <WindowPari />
            <WindowPari />
            <WindowPari />
            <WindowPari />
    </div>
    )
}
const Demi = () => {
    return(
        <div className="containerElim demi">
        <div className="title">Demi-Finale</div>
            <WindowPari />
            <WindowPari />
    </div>
    )
}
const Finale = () => {
    return(
        <div className="containerElim finale">
        <div className="title">Finale</div>
            <WindowPari />
    </div>
    )
}

const PariElim =  () =>{
    return(
        <>
        <div className="bgBet"></div>
        <div className="col">
            <Huitieme />
            <Quart />
            <Demi />
            <Finale />
        </div>
        </>
    )
}
export default PariElim