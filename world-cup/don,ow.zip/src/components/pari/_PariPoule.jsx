import React,{useState} from "react";
import './pariPoule.css' 



const PariPoule = (props) => {
    
    const [selected,setSelected] = useState(null)
    
    /*je dois fetch l'api pour recuperer tout les matchs */

  
    return(<>
                <div className="titlePari">{props.a} VS {props.b}</div>
                <div className="containerPari">
                    <div onClick={()=>{setSelected("A")}} className={`cell A ${selected==="A"?"selected":""}`}>{props.a}</div>
                    <div onClick={()=>{setSelected("N")}} className={`cell nul ${selected==="N"?"selected":""}`}>nul</div>
                    <div onClick={()=>{setSelected("B")}} className={`cell B ${selected==="B"?"selected":""}`}>{props.b}</div>
                </div>
            </>     
    )
}

export default PariPoule