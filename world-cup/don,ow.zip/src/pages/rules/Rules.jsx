import React from "react"
import './rules.css'
const Rules = () => {
    return (   
            <>
                    <div className="backgroundRules"></div>

                    <div className="rulesContainer">
                        <div className="title">Règles du jeu</div>
                        <div className="subtitle">Lors de la phase de poule</div>      
                        <div className="rules">Lorem ipsum dolor sit amet consectetur 
                        adipisicing elit. Aut nemo voluptas dolor neque officiis dolores minus qui, 
                        non laboriosam soluta dolorum facere fugiat eveniet est et ipsum cupiditate deleniti odio.</div> 
                        <div className="rules">Lorem ipsum dolor sit amet consectetur 
                        adipisicing elit. Aut nemo voluptas dolor neque officiis dolores minus qui, 
                        non laboriosam soluta dolorum facere fugiat eveniet est et ipsum cupiditate deleniti odio.</div> 
                        <div className="subtitle">Lors de la phase éliminatoire</div>
                        <div className="rules">Lorem ipsum dolor sit amet consectetur 
                        adipisicing elit. Aut nemo voluptas dolor neque officiis dolores minus qui, 
                        non laboriosam soluta dolorum facere fugiat eveniet est et ipsum cupiditate deleniti odio.</div> 
                        <div className="rules">Lorem ipsum dolor sit amet consectetur 
                        adipisicing elit. Aut nemo voluptas dolor neque officiis dolores minus qui, 
                        non laboriosam soluta dolorum facere fugiat eveniet est et ipsum cupiditate deleniti odio.</div> 
                    </div> 
            </>    
    )
}

export default Rules