import React from "react"
import "./rating.css"
const players = [
    {
    id:1,
    pseudo:"max",
    points:50,
    classement:1
        },
    {
    id:2,
    pseudo:"trs",
    points:40,
    classement:2
        },
    {
    id:3,
    pseudo:"jean",
    points:37,
    classement:1
        },
    {
    id:4,
    pseudo:"samy",
    points:35,
    classement:2
    },
    {
    id:5,
    pseudo:"christ",
    points:30,
    classement:1
        },
    {
    id:6,
    pseudo:"luc",
    points:20,
    classement:2
        },
    {
        id:7,
        pseudo:"max",
        points:50,
        classement:1
            },
        {
        id:8,
        pseudo:"trs",
        points:40,
        classement:2
            },
        {
        id:9,
        pseudo:"jean",
        points:37,
        classement:1
            },
        {
        id:10,
        pseudo:"samy",
        points:35,
        classement:2
        },
        {
        id:11,
        pseudo:"christ",
        points:30,
        classement:1
            },
        {
        id:12,
        pseudo:"luc",
        points:20,
        classement:2
            },
        {
         id:13,
         pseudo:"max",
         points:50,
         classement:1
             },
         {
         id:14,
         pseudo:"trs",
         points:40,
         classement:2
             },
         {
         id:15,
         pseudo:"jean",
         points:37,
         classement:1
             },
         {
         id:16,
         pseudo:"samy",
         points:35,
         classement:2
         },
         {
         id:17,
         pseudo:"christ",
         points:30,
         classement:1
             },
         {
         id:18,
         pseudo:"luc",
         points:20,
         classement:2
             }
            
]
const ColPlayer =(props)=>{
    return(
                <tr>
                    <td>{props.pseudo}</td>
                    <td>{props.points}</td>
                    <td>{props.classement}</td>
                </tr>    
        )
                
}

const Rating = (props) => {
    return (<div className="gray">
      
            <div className="title">LE CLASSEMENT</div>
             <div className="backgroundRating"></div> 
            <div className="tableContainer">
                    <table>
                            <thead >
                                <tr>
                                    <th>Moi</th>
                                    <th>Mes points</th>
                                    <th>Ma place</th>
                                </tr>
                            </thead>
                        <tbody className="user"> 
                          <ColPlayer key={players[2].id} {...players[2]} /> 
                        </tbody>
                        <thead>
                            <tr>
                                <th>Pseudo</th>
                                <th>Points</th>
                                <th>Classement</th>
                            </tr>
                        </thead>
                    {/*fetch l'api pour recuperer toute les données*/}
                        <tbody> 
                              {players.map(e => <ColPlayer key={e.id} {...e} /> )}
                        </tbody>
                    
                    </table>

                </div>
            </div>
    )
}
export default Rating