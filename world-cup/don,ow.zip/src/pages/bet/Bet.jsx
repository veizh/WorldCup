
import "./bet.css"
import React from "react"
import {Link} from "react-router-dom"


const ListBet = () =>{
    return (<>
                <div className="bgBet"></div>
                <div className="grid">
                    <div className="subtitle">FAITES VOS JEUX !</div>
                    <div className="subtitle2"><div className="txt">Il vous reste x grilles de pari a remplir !</div></div>
                    <Link  to="./poule/a">Poule A <i className="fa-solid fa-circle-check"></i></Link>
                    <Link  to="./poule/a">Poule B <i className="fa-solid fa-circle-check"></i></Link>
                    <Link  to="./poule/c">Poule C <i className="fa-solid fa-circle-check"></i></Link>
                    <Link  to="./poule/d">Poule D <i className="fa-solid fa-circle-check"></i></Link>
                    <Link  to="./poule/e">Poule E <i className="fa-solid fa-circle-check"></i></Link>
                    <Link  to="./poule/f">Poule F <i className="fa-solid fa-circle-check"></i></Link>
                    <Link  to="./poule/g">Poule G <i className="fa-solid fa-circle-check"></i></Link>
                    <Link  to="./poule/h">Poule H <i className="fa-solid fa-circle-check"></i></Link>
                    <Link  to="./eliminatoire">Eliminatoires <i className="fa-solid fa-circle-check"></i></Link>
                </div>
            </>   
    )
}

const Bet = () => {
    return (
            <>
               <ListBet />                  
            </>
    )
}
export default Bet

/*<div className="col">
            <PariPoule a="france" b="espagne"/>
            <PariPoule a="Portugal" b="Lithuanie"/>
            <PariPoule a="suisse" b="Suede"/>
            <PariPoule a="USA" b="Angleterre"/>
           </div>*/