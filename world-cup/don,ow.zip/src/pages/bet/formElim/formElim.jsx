import React from "react"
import PariElim from "../../../components/pari/_PariElim"

const FormElim = () =>{
    return(
        <>
        <PariElim />
        </>
    )
}
export default FormElim