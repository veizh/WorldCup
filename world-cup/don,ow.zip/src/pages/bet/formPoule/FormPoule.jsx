import React from "react"
import PariPoule from "../../../components/pari/_PariPoule"

import { useParams } from "react-router-dom";
const FormPoule = (props) =>{
    
    /*Il faut lui balancer les equipes de la poule en question via le paremetre URl*/
    const {poule} = useParams()
    console.log(poule);

        
    return (
            <>
                <div className="col">
                    <PariPoule a="france" b="espagne"/>
                    <PariPoule a="Portugal" b="Lithuanie"/>
                    <PariPoule a="suisse" b="Suede"/>
                    <PariPoule a="USA" b="Angleterre"/>
                </div>
            </>
    )
            
}
export default FormPoule