import './news.css'
import Post from "../../components/posts/_Post"
import React from 'react'

const posts = 
[
    {
    id:1,
    title:"La france remonte",
    msg:"La france a fait une remonté incroyable face a la suède ! et redeviens l'equipe favorite de sa poule",
    date:"13/09/22"
    },
    {
    id:2,
    title:"re-test",
    msg:"je suis le message 2eme que fx devra ecrire ou je raconterait l'actualité et kinkinkninkinkninkin",
    date:"13/09/22"
    },
    {
        id:3,
        title:"La france remonte",
        msg:"La france a fait une remonté incroyable face a la suède ! et redeviens l'equipe favorite de sa pouleLa france aLa france a fait une remonté incroyable face a la suède ! et redeviens l'equipe favorite de sa poule fait une remonté incroyable face a la suède ! et redeviens l'equipe favorite de sa poule",
        date:"13/09/22"
        },
        {
        id:4,
        title:"re-test",
        msg:"je suis le message 2eme que fx devra ecrire ou je raconterait l'actualité et kinkinkninkinkninkin",
        date:"13/09/22"
        },
        {
            id:5,
            title:"La france remonte",
            msg:"La france a fait une remonté incroyable face a la suède ! et redeviens l'equipe favorite de sa poule",
            date:"13/09/22"
            },
            {
            id:6,
            title:"re-test",
            msg:"je suis le message 2eme que fx devra ecrire ou je raconterait l'actualité et kinkinkninkinkninkin",
            date:"13/09/22"
            }
]

const PostFetched = () => {
    {/*je dois ici fetch l'api pour récuperer tout els post ! et les rangé par date !*/}
    return <div className="allPost">
                {posts.map(e => <Post key={e.id} {...e} />)}
            </div>
   

}
const News = () => {

    return (<>
                <div className="backgroundNews"></div>
                <div className="containerPost">
                    <h1>L'info sur la coupe du monde</h1>
                    {/*je dois ici fetch l'api pour récuperer tout els post ! et les rangé par date !*/}
                    <PostFetched />


                </div>
            </>
    )
}
export default News