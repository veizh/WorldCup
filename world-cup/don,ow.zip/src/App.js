/*import { useNavigate } from "react-router-dom";
import { useEffect, useState } from 'react';*/
import './App.css';
/*import FormInput from './components/inputs/_FormInput';*/

function App({children}) {
 /* const Navigate = useNavigate()
  const [Statut, setStatut] = useState(null)

 useEffect(()=>{
  if(localStorage.getItem('jwt') && !Statut){
    const ok = false
    console.log("l13")
    if(ok){setStatut(true) }
    if(!ok){
      console.log("l17")
      setStatut(false)
      Navigate('/login')
    }
  }
 },[Statut])*/
  return <>
    {children}
  </>
 /* useEffect(()=>{  
   
      if(Statut === null){
        if(localStorage.getItem('jwt')){
          console.log('fetch jwt')
          setStatut(true)
        }
      }*/
      
 /* const path = Statut?"/Acceuil":"/LogIn"
  navigate(path)
  })*/
}

export default App;
